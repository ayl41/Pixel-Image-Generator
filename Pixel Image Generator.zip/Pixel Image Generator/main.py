#######################################################################

#CMPT 120 - D200
#Name: Andrew Lee (Student # - 301389961)
#Date: July 30, 2021
#Assignment: Pixel Art Generator - Final Project

#######################################################################

#Import modules:
import image_helpers as mod
import csv
import time as t
import string

#Define  variables for costs and total costs:
cost = 0.00
t_cost = 0.00

#Define and assign variable to detect if a tool is used:
tool_used = False

#Define function to verify if file exists:
def verify_File(file_name):
    try:
        file = open(file_name)
        file.close()
        file_status = True
    except:
        file_status = False
    return file_status

#Define function to verify if hex code is valid:
def verify_Hex(valid_hex):
    try:
        hex = valid_hex.lstrip("#")
        for x in (0, 2, 4):
            hex_dec = int(hex[x:x+2], 16)
        hex_status = True
    except:
        hex_status = False
    return hex_status

#Make both verification variables FALSE:
hex_status = False
file_status = False

#Define functionality 1:
def func_1(valid_hex):
    hex = valid_hex.lstrip("#")
    rgb = []
    for x in (0, 2, 4):
        hex_dec = int(hex[x:x+2], 16)
        rgb.append(hex_dec)
    return rgb

#Define functionality 2:
def func_2(file_name):
    file = open(file_name)
    r = csv.reader(file)

    for line in r:
        length = len(line)
    img = mod.getBlackImage(length,length)
    file.seek(0)

    for i, x in zip(line, range(length)):
        rgb = func_1(i)
        for y in range(length):
            pixel = img[x][y]
            pixel[0] = rgb[0]
            pixel[1] = rgb[1]
            pixel[2] = rgb[2]
    mod.showImage(img)
    return img

#Define functionality 3:
def func_3(file_name):
    file = open(file_name)
    r = csv.reader(file)

    for line in r:
        length = len(line)

    img = mod.getBlackImage(length,length)
    file.seek(0)

    for line, y in zip(r, range(length)):
        for i, x in zip(line, range(length)):
            rgb = func_1(i)
            pixel = img[x][y]
            pixel[0] = rgb[0]
            pixel[1] = rgb[1]
            pixel[2] = rgb[2]
    mod.showImage(img)
    return img, length

#Define functionality 4:
def func_4(file_name):
    img, length = func_3(file_name)

    for x in range(length):
        for y in range(length):
            pixel = img[x][y]
            r = pixel[0]
            g = pixel[1]
            b = pixel[2]

            average = (r+g+b)/3

            pixel[0] = average
            pixel[1] = average
            pixel[2] = average
    mod.showImage(img)
    return img

#Define functionality 5:
def func_5(file_name, width):
    file = open(file_name)
    r = csv.reader(file)

    for line in r:
        length = len(line)

    img = mod.getBlackImage(length,length)
    file.seek(0)
    x_pos = 1
    y_pos = 0

    for line, y in zip(r, range(length)):
        for i, x in zip(line, range(length)):
            y_pos += 1
            rgb = func_1(i)
            pixel = img[x][y]
            pixel[0] = rgb[0]
            pixel[1] = rgb[1]
            pixel[2] = rgb[2]

            r = pixel[0]
            g = pixel[1]
            b = pixel[2]


            if x_pos <= width:
                x_pos += 1
                r += 100
                g -= 100
                b -= 100
                if r > 255:
                    r = 255
                if g < 0:
                    g = 0
                if b < 0:
                    b = 0

                pixel[0] = r
                pixel[1] = g
                pixel[2] = b
            elif x_pos > width:
                x_pos += 1
            if x_pos > (width*2):
                x_pos = 1

            if y_pos == length:
                y_pos = 0
                x_pos = 1
    mod.showImage(img)
    return img

#Define functionality 6:
def func_6(file_name):
    file = open("color-bar.csv")
    r = csv.reader(file)
    rows = 0
    for line in r:
        col = len(line)
        rows += 1

    length = col*100
    height = rows*100

    all_col = []
    for i in line:
        col_code = func_1(i)
        all_col.append(col_code)

    img = mod.getBlackImage(length,height)
    file.seek(0)
    counter = 100

    for x in range(length):
        for y in range(height):
            if counter == (length//col):
                rgb = all_col[0]
                all_col.remove(rgb)
                counter = 0
            pixel = img[x][y]
            pixel[0] = rgb[0]
            pixel[1] = rgb[1]
            pixel[2] = rgb[2]
        counter += 1

    mod.showImage(img)
    return img

#Create intro with menu options:
def menu_Options():
    print("""
===================================================

Name: {}
Current Total Outstanding Balance: ${}

===================================================

Please Choose One Of The Following Options:

(0) - Exit
(1) - Convert HEX Colour to RGB List
(2) - Create Basic Poster
(3) - Create Pixel Art Poster
(4) - Create GreyScale Pixel Art Poster
(5) - Create Pixel Art Poster With Red Bar Effects
(6) - Create Horizontal Bar Scaled Pixel Art Poster
    """.format(name, t_cost))

#Introduce user to pixel image creator tool:
print("""
Welcome To The Pixel Image Creator Tool!!!

What's Your Name?
""")

name = input(">>> ")

print("""
===================================================

Nice To Meet You, {}!
Welcome To The Pixel Image Creator Tool!
The Program Will Begin Shortly...
""".format(string.capwords(name)))

#Define functions for error messages:
def error():
    print("""
===================================================

    Invalid Entry.
    Please Try Again.
    """)

def verify_Failure():
    print("""
===================================================

    Error - File Verification Failed:
        > The Program Was Unable To Locate
          The Selected File.

    Please Ensure That The Following File
    Exists Within The Same Directory...
        > {}
    """.format(file_name))

t.sleep(3)

#Define variables for both the entire tool and the menu:
access = True
menu = False

#Start tool:
while access is True:
    menu_Options()
    selection = input(">>> ")

    if selection.isdigit():
        selection = int(selection)
        menu = True
    else:
        error()
        t.sleep(2)
        menu = False

    while menu is True:

        #Run tool for selection 0:
        if selection == 0:
            access = False
            menu = False

        #Run tool for selection 1:
        elif selection == 1:
            print("""
===================================================

    Option (1) Selected:
        > Convert HEX Colour To RGB List

    Do You Want To Continue? [Y/N]
            """)
            input1 = input(">>> ")
            input1 = input1.lower()
            if input1 == "yes" or input1 == "y":
                print("""
===================================================

    Please Enter A Valid Hex Coded Colour.
                """)
                valid_hex = input(">>> ")
                if len(valid_hex) == 7 and valid_hex[0] == "#":
                    if verify_Hex(valid_hex) is True:
                        print("""
===================================================

    Translating HEX Colour Code To RGB List...
                        """)
                        t.sleep(2)
                        rgb = func_1(valid_hex)
                        print("""
===================================================

    HEX Colour Code: {}
    RGB List Value: {}

    Thank You For Your Selection!
    $0.25 Has Been Charged To Your Account.
                        """.format(valid_hex.upper(), rgb))
                        cost = 0.25
                        t_cost += cost
                        t.sleep(5)
                        menu = False
                        tool_used = True
                    elif verify_Hex(valid_hex) is False:
                        error()
                        t.sleep(3)
                        selection = selection

                else:
                    error()
                    t.sleep(3)
                    selection = selection
            elif input1 == "no" or input1 == "n":
                print("""
===================================================

    Selection Cancelled.
                """)
                t.sleep(3)
                menu = False
            else:
                error()
                t.sleep(3)
                selection = selection


#########################################################

        #Run tool for selection 2:
        elif selection == 2:
            print("""
===================================================

    Option (2) Selected:
        > Create Basic Poster

    There Is Only One Valid Data File
    For This Option:
        > basic.csv

    Do You Want To Continue? [Y/N]
            """)
            input2 = input(">>> ")
            input2 = input2.lower()
            if input2 == "yes" or input2 == "y":
                file_status = verify_File("basic.csv")
                if file_status is True:
                    print("""
===================================================

    Generating Basic Poster Image...
                    """)
                    t.sleep(2)
                    mod.saveImage(func_2("basic.csv"), "poster-basic.jpg")
                    print("""
===================================================

    Image Saved As:
        > poster-basic.jpg

    Thank You For Your Selection!
    $1.00 Has Been Charged To Your Account.
                    """)
                    t.sleep(5)
                    cost = 1.00
                    t_cost += cost
                    menu = False
                    tool_used = True
                else:
                    file_name = "basic.csv"
                    verify_Failure()
                    t.sleep(5)
            elif input2 == "no" or input2 == "n":
                print("""
===================================================

    Selection Cancelled.
                """)
                t.sleep(3)
                menu = False
            else:
                error()
                t.sleep(3)
                selection = selection




#########################################################

        #Run tool for selection 3 or 4:
        elif selection == 3 or selection == 4:
            if selection == 3:
                option_name = "Create Pixel Art Poster"
            elif selection == 4:
                option_name = "Create GreyScale Pixel Art Poster"
            print("""
===================================================

    Option ({}) Selected:
        > {}

    Do You Want To Continue? [Y/N]
            """.format(selection, option_name))
            input3 = input(">>> ")
            input3 = input3.lower()
            if input3 == "yes" or input3 == "y":
                print("""
===================================================

    Please Choose One Of The Following Images:
        > Cactus
        > Flamingo
        > Giraffe
        > House
        > Parrot
        > Tree
                """)
                img_input = input(">>> ").lower()
                img_input = img_input.strip()
                options = ["cactus", "flamingo",
                "giraffe", "house", "parrot", "tree"]
                if img_input not in options:
                    error()
                    t.sleep(2)
                    selection = selection
                else:
                    print("""
===================================================

    Please Choose One Of The Following Sizes:
        > 50
        > 100
        > 200
        > 400
        > 800
                    """)
                    size_input = input(">>> ")
                    size_input = size_input.strip()
                    if size_input.isdigit():
                        size_input = int(size_input)
                    options2 = [50, 100, 200, 400, 800]
                    if size_input in options2:
                        file_name = "{}-{}.csv".format(img_input, size_input)
                        file_status = verify_File(file_name)
                        if file_status is True:
                            print("""
===================================================

    Generating Pixel Art Poster...
        > Image Selection: "{}"
        > Dimensions: {} x {}
                            """.format(img_input.upper(), size_input, size_input))


                            if selection == 3:
                                img, length = func_3(file_name)
                                saveName = "poster-original-{}-{}.jpg".format(img_input, size_input)
                            elif selection == 4:
                                img = func_4(file_name)
                                saveName = "poster-grey-{}-{}.jpg".format(img_input, size_input)

                            mod.saveImage(img, saveName)

                            t.sleep(3)
                            if size_input == 50:
                                cost = 0.00
                            elif size_input == 100:
                                cost = 1.00
                            elif size_input == 200:
                                cost = 2.00
                            elif size_input == 400:
                                cost = 4.00
                            elif size_input == 800:
                                cost = 8.00
                            print("""
===================================================

    Image Saved As:
        > {}

    Thank You For Your Selection!
    ${} Has Been Charged To Your Account.
                            """.format(saveName, cost))
                            t_cost += cost
                            t.sleep(5)
                            menu = False
                            tool_used = True
                        else:
                            verify_Failure()
                            t.sleep(3)

                    else:
                        error()
                        t.sleep(3)
                        selection = selection
            elif input3 == "no" or input3 == "n":
                print("""
===================================================

    Selection Cancelled.
                """)
                t.sleep(3)
                menu = False
            else:
                error()
                t.sleep(3)
                selection = selection



#########################################################

        #Run tool for selection 5:
        elif selection == 5:
            print("""
===================================================

    Option (5) Selected:
        > Create Pixel Art Poster With
          Red Bar Effects

    Do You Want To Continue? [Y/N]
            """)
            input5 = input(">>> ")
            input5 = input5.lower()
            if input5 == "yes" or input5 == "y":
                print("""
===================================================

    Please Choose One Of The Following Images:
        > Cactus
        > Flamingo
        > Giraffe
        > House
        > Parrot
        > Tree
                """)
                img_input = input(">>> ").lower()
                img_input = img_input.strip()
                options = ["cactus", "flamingo",
                "giraffe", "house", "parrot", "tree"]
                if img_input not in options:
                    error()
                    t.sleep(2)
                    selection = selection
                else:
                    print("""
===================================================

    Please Choose One Of The Following Sizes:
        > 50
        > 100
        > 200
        > 400
        > 800
                    """)
                    size_input = input(">>> ")
                    size_input = size_input.strip()
                    if size_input.isdigit():
                        size_input = int(size_input)
                    options2 = [50, 100, 200, 400, 800]
                    if size_input in options2:
                        file_name = "{}-{}.csv".format(img_input, size_input)
                        print("""
===================================================

    Please Choose One Of The Following Bar Widths:
        > Narrow (15 Pixels)
        > Wide (75 Pixels)

    [Note]: The Tool Will Automatically Assign The
            "Narrow (15 Pixels)" Bar Width Unless
            Specified Otherwise.
                        """)
                        width_input = input(">>> ").lower()
                        width_input = width_input.strip()
                        if width_input.isdigit():
                            width_input = int(width_input)

                        file_status = verify_File(file_name)
                        if file_status is True:
                            if width_input == 75 or width_input == "wide":
                                width_input = 75
                                img = func_5(file_name, 75)
                                saveName = "poster-bars-{}-{}-{}.jpg".format(width_input, img_input, size_input)
                            else:
                                width_input = 15
                                img = func_5(file_name, 15)
                                saveName = "poster-bars-{}-{}-{}.jpg".format(width_input, img_input, size_input)

                            print("""
===================================================

    Generating Pixel Art Poster...
        > Image Selection: "{}"
        > Dimensions: {} x {}
        > Bar Size: {}
                            """.format(img_input.upper(), size_input, size_input, width_input))

                            mod.saveImage(img, saveName)

                            t.sleep(3)
                            if size_input == 50:
                                cost = 0.00*2
                            elif size_input == 100:
                                cost = 1.00*2
                            elif size_input == 200:
                                cost = 2.00*2
                            elif size_input == 400:
                                cost = 4.00*2
                            elif size_input == 800:
                                cost = 8.00*2
                            print("""
===================================================

    Image Saved As:
        > {}

    Thank You For Your Selection!
    ${} Has Been Charged To Your Account.
                            """.format(saveName, cost))
                            t_cost += cost
                            t.sleep(5)
                            menu = False
                            tool_used = True
                        else:
                            verify_Failure()
                    else:
                        error()
                        t.sleep(3)
                        selection = selection
            elif input3 == "no" or input3 == "n":
                print("""
===================================================

    Selection Cancelled.
                """)
                t.sleep(3)
                menu = False
            else:
                error()
                t.sleep(3)
                selection = selection


#########################################################

        #Run tool for selection 6:
        elif selection == 6:
            print("""
===================================================

    Option (6) Selected:
        > Create Horizontal Bar Scaled
          Pixel Art Poster

    There Is Only One Valid Data File
    For This Option:
        > color-bar.csv

    Do You Want To Continue? [Y/N]
            """)
            input6 = input(">>> ")
            input6 = input6.lower()
            if input6 == "yes" or input6 == "y":
                file_status = verify_File("color-bar.csv")
                if file_status is True:
                    print("""
===================================================

    Generating Horizontal Bar Poster Image...
                    """)
                    t.sleep(2)
                    img = func_6("color-bar.csv")
                    mod.saveImage(img, "poster-color-bar.jpg")
                    print("""
===================================================

    Image Saved As:
        > poster-color-bar.jpg

    Thank You For Your Selection!
    $1.00 Has Been Charged To Your Account.
                    """)
                    t.sleep(5)
                    cost = 1.00
                    t_cost += cost
                    menu = False
                    tool_used = True
                else:
                    file_name = "color-bar.csv"
                    verify_Failure()
                    t.sleep(5)
            elif input6 == "no" or input6 == "n":
                print("""
===================================================

    Selection Cancelled.
                """)
                t.sleep(3)
                menu = False
            else:
                error()
                t.sleep(3)
                selection = selection
        else:
            error()
            t.sleep(2)
            menu = False



#########################################################



#Compute lucky number:
vowels = {'a':97, 'e':101, 'i':105, 'o':111, 'u':117, 'A':65, 'E':69, 'I':73, 'O':79, 'U':85}
ascii_sum = 0

for v in range(len(name)):
    if name[v] in vowels:
        ascii_num = vowels.get(name[v])
        ascii_num *= v
        ascii_sum += ascii_num

#I did this instead of using "%" because I wasn't getting the correct remainder:
num1 = (ascii_sum + t_cost)
num2 = len(name)
num3 = num1//num2
lucky_num = int(num1 - (num3*num2))

if tool_used is True:
    print("""
===================================================

    Thank You For Using The Pixel Image
    Creator Tool!

        > Total Outstanding Balance: ${}
        > Lucky Number: [{}]

    Hope To See You Again Soon!
    Have A Great Day :)
    """.format(t_cost, lucky_num))
else:
    print("""
===================================================

    I'm Sorry That You Didn't Get To Use The
    Pixel Image Creator Tool. Maybe Next Time!

        > Lucky Number: [{}]

    Hope To See You Again Soon!
    Have A Great Day :)
    """.format(lucky_num))
#End program


